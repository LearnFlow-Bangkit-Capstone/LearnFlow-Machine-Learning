from flask import Flask, jsonify, request
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow import keras
from keras import layers
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences

# Menggunakan framework Flask
app = Flask(__name__)

# Inisialisasi dataset
dataset_file = 'D:\\BELAJAR PYTHON\\Capstone\\dataset.csv'
dataset = pd.read_csv(dataset_file)

# Inisialisasi model neural network dengan Keras
def create_neural_network_model(input_dim, output_dim):
    model = keras.Sequential([
        layers.Embedding(input_dim=input_dim, output_dim=64),
        layers.LSTM(64),
        layers.Dense(output_dim, activation='softmax')
    ])
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model

# Tokenisasi dan padding untuk input model neural network
tokenizer = Tokenizer()
tokenizer.fit_on_texts(dataset['Sentence'])
X = tokenizer.texts_to_sequences(dataset['Sentence'])
X = pad_sequences(X)

# One-hot encode labels
label_encoder = LabelEncoder()
y = label_encoder.fit_transform(dataset['Type'])
num_classes = len(label_encoder.classes_)
y = keras.utils.to_categorical(y, num_classes=num_classes)

# Bagi dataset menjadi data pelatihan dan data uji
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Inisialisasi model neural network
input_dim = len(tokenizer.word_index) + 1
output_dim = num_classes
model = create_neural_network_model(input_dim, output_dim)

# Latih model dengan data pelatihan
model.fit(X_train, y_train, epochs=10, batch_size=32, validation_data=(X_test, y_test))

# Simpan model (opsional)
model.save('Capstone_style_recommendation_model.h5')

# Jadi program yang di bawah ini dia fungsinya ketika nanti di deploy, Jawaban user yang masuk akan di simpan untuk pembaruan model
# dan model tersebut akan di training ulang

# @app.route ini untuk memetakan URL ke fungsi tertentu
# nah pada @app.route ini tujuannya adalah menulis ke database di cloud
# karena belum ada itu berarti nama domainnya berupa ip address contoh (127.1.1.5/update_model)

# jadi @app.route ini kita seperti menulis isi dari web site tersebut
# contoh nama domain www.example.com/hello, nah kita pakai @app.route('/hello') terus dibawah @app.route tulis

# def x():
#   return "hello world"

# nanti hasilnya di website www.example.com/hello adalah tulisan hello world

# Bagian ini berupa endpoint untuk menerima jawaban dari pengguna dan memperbarui model
@app.route('/update_model', methods=['POST'])
def update_model():
    try:
        # Ambil jawaban dari pengguna
        user_answer = request.json['Sentence']
        user_style = request.json['style']

        # Tambahkan data ke dataset
        new_data = pd.DataFrame({'Sentence': [user_answer], 'Type': [user_style]})
        dataset = pd.concat([dataset, new_data], ignore_index=True)

        # Tokenisasi dan padding untuk input model neural network
        X = tokenizer.texts_to_sequences(dataset['Sentence'])
        X = pad_sequences(X)

        # One-hot encode labels
        # One-hot encoding adalah teknik untuk merepresentasikan variabel kategori sebagai nilai numerik
        y = label_encoder.transform(dataset['Type'])
        y = keras.utils.to_categorical(y, num_classes=num_classes)

        # Bagi dataset menjadi data pelatihan dan data uji
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

        # Latih ulang model neural network
        model.fit(X_train, y_train, epochs=10, batch_size=32, validation_data=(X_test, y_test))

        # Simpan model (opsional)
        model.save('Capstone_style_recommendation_model.h5')

        user_input_sequence = tokenizer.texts_to_sequences([user_answer])
        user_input_padded = pad_sequences(user_input_sequence)
        prediction = model.predict(user_input_padded)
        predicted_style = label_encoder.inverse_transform([prediction.argmax()])[0]

        # jsonify menyetel jenis konten dan mengembalikan hasil respon ke data JSON
        # jsonify digunakan untuk mempermudah membuat APIl, karena respon datanya berbentuk JSON

        # How to append to big querry using cloud function
        # How to append data pandas frame to big querry 
        return jsonify({'message': 'Model updated successfully', 'predicted_style': predicted_style})

    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True)
